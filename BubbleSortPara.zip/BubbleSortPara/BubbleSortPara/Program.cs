﻿/* Programmer: Kyle N. Jenson
 * Class: Artificial Intelligence
 * Description: Comparing sequencial and paralellized Bubble Sort times.
 */

using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace BubbleSortPara
{
    class Program
    {
        static void Main(string[] args)
        {
            //Unparallelized Bubble Sort Section - Functional
            //stopwatch functional
            //stopwatch begins...
            Stopwatch stopwatch = new Stopwatch();

            stopwatch.Start();

            int[] array = { 101, 1, 305, 44, 6, 27, 828 };
            int temp;

            foreach (int a in array)
                Console.Write(a + ", ");
            Console.WriteLine();

            //Bubble Sort...
            for (int j =0; j<=array.Length-2;j++)
            {
                
                for (int i=0;i<=array.Length-2;i++)
                {
                    if (array[i] > array[i+1])
                    {
                        temp = array[i + 1];
                        array[i + 1] = array[i];
                        array[i] = temp;
                    }
                }
                
            }

            //stopwatch stops...
            stopwatch.Stop();
            
            Console.Error.WriteLine("Bubble sort unparalellized performed in milliseconds: {0}",
                stopwatch.ElapsedMilliseconds);
            stopwatch.Reset();
            Console.WriteLine("Simple Bubble Sort (Unparallel) Complete:");
            foreach (int p in array)
                Console.Write(p + ", ");
            Console.WriteLine();
            Console.WriteLine();

            //Parallelized Section - first 'for' statement parallelized...
            //stopwatch1 begins...
            Stopwatch stopwatch1 = new Stopwatch();
            stopwatch1.Start();
            int[] arrayp = { 101, 1, 305, 44, 6, 27, 828 };
            int tempp;

            foreach (int a in arrayp)
                Console.Write(a + ", ");
            Console.WriteLine();

            int arLength = arrayp.Length - 2;
            //Bubble Sort...
            Parallel.For(0, arLength, j =>
             {

                 for (int i = 0; i<=arrayp.Length - 2; i++)
                 {
                     if (arrayp[i] > arrayp[i + 1])
                     {
                         tempp = arrayp[i + 1];
                         arrayp[i + 1] = arrayp[i];
                         arrayp[i] = tempp;
                     }
                 }

             });
            //stopwatch1 stops...
            stopwatch1.Stop();
            Console.Error.WriteLine("Bubble sort (first 'for' parallelized) performed in milliseconds: {0}",
                stopwatch1.ElapsedMilliseconds);
            stopwatch1.Reset();
            Console.WriteLine("Simple Bubble Sort (Parallel) Complete:");
            foreach (int p in arrayp)
                Console.Write(p + ", ");
            Console.WriteLine();
            Console.WriteLine();

            //Parallelized Section - second 'for' statement parallelized...
            //stopwatch2 begins...
            Stopwatch stopwatch2 = new Stopwatch();
            stopwatch2.Start();
            int[] arrayp2 = { 101, 1, 305, 44, 6, 27, 828 };
            int tempp2;

            foreach (int a in arrayp2)
                Console.Write(a + ", ");
            Console.WriteLine();

            int arLength2 = arrayp2.Length - 2;
            //Bubble Sort...
            for (int j = 0; j <= arrayp2.Length - 2; j++)
            {

                Parallel.For (0, arLength2, i=>
                {
                    if (arrayp2[i] > arrayp2[i + 1])
                    {
                        tempp2 = arrayp2[i + 1];
                        arrayp2[i + 1] = arrayp2[i];
                        arrayp2[i] = tempp2;
                    }
                });

            }
            //stopwatch2 stops...
            stopwatch2.Stop();
            Console.Error.WriteLine("Bubble sort (second 'for' parallelized) performed in milliseconds: {0}",
                stopwatch2.ElapsedMilliseconds);
            stopwatch2.Reset();
            Console.WriteLine("Simple Bubble Sort (Parallel) Complete:");
            foreach (int p in arrayp2)
                Console.Write(p + ", ");
            Console.WriteLine();
            Console.WriteLine();

            //Parallelized Section - both 'for' statement parallelized...
            //stopwatch2 begins...
            Stopwatch stopwatch3 = new Stopwatch();
            stopwatch3.Start();
            int[] arrayp3 = { 101, 1, 305, 44, 6, 27, 828 };
            int tempp3;

            foreach (int a in arrayp3)
                Console.Write(a + ", ");
            Console.WriteLine();

            
            int arLength3 = arrayp3.Length - 2;

            //Bubble Sort...
            Parallel.For(0, arLength3, j =>
            {

                Parallel.For(0, arLength3, i =>
                {
                    if (arrayp3[i] > arrayp3[i + 1])
                    {
                        tempp3 = arrayp3[i + 1];
                        arrayp3[i + 1] = arrayp3[i];
                        arrayp3[i] = tempp3;
                    }
                });

            });
            //stopwatch2 stops...
            stopwatch3.Stop();
            Console.Error.WriteLine("Bubble sort (both 'for' parallelized) performed in milliseconds: {0}",
                stopwatch3.ElapsedMilliseconds);
            stopwatch3.Reset();
            Console.WriteLine("Simple Bubble Sort (Parallel) Complete:");
            foreach (int p in arrayp3)
                Console.Write(p + ", ");
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
