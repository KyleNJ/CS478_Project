﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZXing;
using ZXing.Common;
using ZXing.QrCode;


namespace Assignment1QRCODE2
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void GenerateMyQCCode(string QCText)
        {
            var QCwriter = new BarcodeWriter();
            QCwriter.Format = BarcodeFormat.QR_CODE;
            var result = QCwriter.Write(QCText);
            string path = Server.MapPath("~/images/MyQRImage.jpg");
            var barcodeBitmap = new Bitmap(result);

            using (MemoryStream memory = new MemoryStream())
            {
                using (FileStream fs = new FileStream(path,
                   FileMode.Create, FileAccess.ReadWrite))
                {
                    barcodeBitmap.Save(memory, ImageFormat.Jpeg);
                    byte[] bytes = memory.ToArray();
                    fs.Write(bytes, 0, bytes.Length);
                }
            }
            imgageQRCode.Visible = true;
            imgageQRCode.ImageUrl = "~/images/MyQRImage.jpg";

        }

        private void ReadQRCode()
        {
            var QCreader = new BarcodeReader();
            string QCfilename = Path.Combine(Request.MapPath
               ("~/images"), "MyQRImage.jpg");
            var QCresult = QCreader.Decode(new Bitmap(QCfilename));
            if (QCresult != null)
            {
                lblQRCode.Text = "My QR Code: " + QCresult.Text;
            }
        }

        protected void btnQCRead_Click(object sender, EventArgs e)
        {
            ReadQRCode();
        }

        protected void btnQCGenerate_Click(object sender, EventArgs e)
        {
            
                GenerateMyQCCode(txtQCCode.Text);
           

        }

        protected void txtQCCode_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {

        }

        //protected void txtQCCode(object sender, EventArgs e)
        //{

        //}

        protected void TextBox1_TextChanged1(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged2(object sender, EventArgs e)
        {

        }

        //protected void Button1_Click1(object sender, EventArgs e, string QCText)
        //{
        //    var QCwriter = new BarcodeWriter();
        //    QCwriter.Format = BarcodeFormat.QR_CODE;
        //    var result = QCwriter.Write(QCText);
        //    string path = Server.MapPath("~/images/MyQRImage.jpg");
        //    var barcodeBitmap = new Bitmap(result);
        //    FileUpload1.SaveAs(path + FileUpload1.FileName);
        //    System.Drawing.Image logo = System.Drawing.Image.FromFile(path + FileUpload1.Filename);
        //    using (MemoryStream memory = new MemoryStream())
        //    {
        //        using (FileStream fs = new FileStream(path,
        //           FileMode.Create, FileAccess.ReadWrite))
        //        {
        //            barcodeBitmap.Save(memory, ImageFormat.Jpeg);
        //            byte[] bytes = memory.ToArray();
        //            fs.Write(bytes, 0, bytes.Length);
        //        }
        //    }
        //    imgageQRCode.SaveAs(path + "~/images/MyQRImage.jpg", ImageFormat.Jpeg);


        //    imgageQRCode.Visible = true;
        //    imgageQRCode.ImageUrl = "~/images/MyQRImage.jpg";
        //}
    }
}